# 快乐屋 - 多媒体内容浏览平台

一个基于 Next.js 的多媒体内容浏览网站，支持小说、动漫、电视剧、综艺、短剧五种类型的内容浏览。

## 技术栈

- **框架**: Next.js 16 (App Router)
- **语言**: TypeScript
- **样式**: Tailwind CSS 4
- **构建工具**: Next.js 内置构建系统

## 功能特性

- 📚 支持小说、动漫、电视剧、综艺、短剧五种内容类型
- 🌍 按国家、年份自动分类
- 📱 响应式设计，支持多端访问
- 🎬 视频播放功能（倍速、投屏）
- 📖 小说阅读功能（章节切换、书签管理）
- 💾 阅读进度自动保存
- 🔍 内容搜索和筛选

## 本地开发

### 环境要求

- Node.js 18.17 或更高版本
- pnpm 8.0 或更高版本

### 安装依赖

```bash
pnpm install
```

### 启动开发服务器

```bash
pnpm dev
```

访问 [http://localhost:5000](http://localhost:5000) 查看网站。

### 构建生产版本

```bash
pnpm build
```

### 启动生产服务器

```bash
pnpm start
```

## Vercel 部署

### 方法一：通过 Vercel Dashboard 部署

1. **准备代码仓库**
   - 将项目推送到 GitHub 仓库
   - 确保仓库是公开的或已授权 Vercel 访问

2. **在 Vercel 导入项目**
   - 访问 [vercel.com](https://vercel.com)
   - 点击 "Add New Project"
   - 选择你的 GitHub 仓库
   - 点击 "Import"

3. **配置项目**
   - **Framework Preset**: Next.js（自动检测）
   - **Build Command**: `pnpm build`（自动填充）
   - **Output Directory**: `.next`（自动填充）
   - **Install Command**: `pnpm install`（如果需要，可以手动设置）

4. **环境变量**（如果需要）
   - 在项目设置中添加所需的环境变量
   - 例如：`DATABASE_URL`、`NEXT_PUBLIC_API_KEY` 等

5. **部署**
   - 点击 "Deploy" 按钮
   - 等待构建完成（通常需要 2-5 分钟）
   - 部署成功后会获得一个 `.vercel.app` 域名

### 方法二：通过 Vercel CLI 部署

1. **安装 Vercel CLI**

```bash
pnpm add -g vercel
```

2. **登录 Vercel**

```bash
vercel login
```

3. **部署项目**

```bash
vercel
```

按照提示完成部署配置：
- 选择是否链接到现有项目
- 确认项目设置
- 等待部署完成

4. **生产环境部署**

```bash
vercel --prod
```

### 部署后配置

1. **自定义域名**
   - 在 Vercel 项目设置中添加自定义域名
   - 配置 DNS 记录指向 Vercel

2. **环境变量管理**
   - 在 Settings > Environment Variables 中管理环境变量
   - 区分 Production、Preview、Development 环境

3. **性能优化**
   - 启用 Edge Runtime（如果适用）
   - 配置图片优化
   - 设置 CDN 缓存策略

## 项目结构

```
├── src/
│   ├── app/              # Next.js App Router 页面
│   │   ├── play/[id]/    # 播放页面
│   │   └── ...
│   ├── components/       # React 组件
│   ├── data/            # 模拟数据
│   └── types/           # TypeScript 类型定义
├── public/              # 静态资源
├── next.config.ts       # Next.js 配置
├── tailwind.config.ts   # Tailwind CSS 配置
└── package.json         # 项目依赖
```

## 常见问题

### Q: 部署后页面显示 404 错误？

A: 检查以下几点：
- 确保 `src/app/` 目录下有 `page.tsx` 文件
- 检查路由路径是否正确
- 清除 Vercel 缓存后重新部署

### Q: 构建失败怎么办？

A: 常见原因：
- TypeScript 类型错误：运行 `pnpm build` 本地测试
- 依赖版本冲突：检查 `package.json` 中的版本
- 内存不足：升级 Vercel 账户或优化构建

### Q: 如何配置环境变量？

A:
1. 在 Vercel Dashboard 进入项目设置
2. 选择 Environment Variables
3. 添加变量名和值
4. 选择环境（Production/Preview/Development）
5. 重新部署项目以应用更改

## 许可证

MIT

---

如有问题，请通过 [GitHub Issues](https://github.com/LC0225/happy-house/issues) 联系。
